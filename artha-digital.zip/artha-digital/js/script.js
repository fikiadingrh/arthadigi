// ============================================================
// ARTHA DIGITAL — site script
// Handles: mobile nav toggle, footer year, contact form submit
// ============================================================

document.addEventListener('DOMContentLoaded', () => {

  // ---- Mobile nav toggle ----
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('main-nav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      navToggle.classList.toggle('is-active', isOpen);
    });

    // Close menu after tapping a link (mobile)
    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // ---- Footer year ----
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  // ---- Contact form ----
  // No backend is connected yet. This opens the visitor's email client
  // pre-filled with their message, so the form works immediately after
  // deployment. Swap this for a form service (e.g. Formspree, Resend,
  // your own API) whenever you're ready to collect submissions directly.
  const form = document.getElementById('contactForm');
  const status = document.getElementById('formStatus');

  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const name = form.name.value.trim();
      const company = form.company.value.trim();
      const contact = form.contact.value.trim();
      const service = form.service.value;
      const message = form.message.value.trim();

      if (!name || !contact) {
        status.textContent = 'Mohon lengkapi nama dan kontak Anda.';
        status.style.color = '#E8622C';
        return;
      }

      const subject = encodeURIComponent(`Permintaan Konsultasi — ${name}`);
      const body = encodeURIComponent(
        `Nama: ${name}\n` +
        `Nama Usaha: ${company || '-'}\n` +
        `Kontak: ${contact}\n` +
        `Layanan Diminati: ${service}\n\n` +
        `Pesan:\n${message || '-'}`
      );

      window.location.href = `mailto:hello@arthadigital.id?subject=${subject}&body=${body}`;

      status.textContent = 'Membuka aplikasi email Anda untuk mengirim permintaan...';
      status.style.color = '#0D4C9B';
    });
  }

  // ---- Sticky header shadow on scroll ----
  const header = document.getElementById('header');
  if (header) {
    const onScroll = () => {
      header.style.boxShadow = window.scrollY > 8
        ? '0 8px 24px -18px rgba(11,18,32,0.35)'
        : 'none';
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }
});
