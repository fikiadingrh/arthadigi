# Artha Digital — Website Company Profile

Website profil perusahaan untuk **Artha Digital** (PT Artha Jaya Digital). Dibangun sebagai situs statis (HTML/CSS/JS murni) — tanpa proses build — sehingga risiko error saat deploy sangat kecil.

## Struktur Proyek

```
artha-digital/
├── index.html        → seluruh konten & struktur halaman
├── css/style.css      → seluruh styling
├── js/script.js        → menu mobile, form kontak, efek scroll
├── assets/logo.png    → logo Artha Digital (sudah terpasang)
└── README.md
```

## Sebelum Publikasi — Yang Perlu Anda Perbarui

Buka `index.html`, cari bagian `KONTAK`, lalu sesuaikan:

1. **Email**: ganti `hello@arthadigital.id` dengan email bisnis Anda (muncul di 2 tempat: bagian kontak & `js/script.js`).
2. **WhatsApp**: ganti nomor pada `https://wa.me/6281234567890` dengan nomor aktif (format: `62` + nomor tanpa angka 0 di depan).
3. **Instagram**: ganti `@arthadigital.id` dan tautannya sesuai akun resmi.
4. **Domisili usaha**: sesuaikan bila diperlukan.

Form kontak saat ini akan membuka aplikasi email pengunjung (mailto) berisi pesan yang sudah terisi otomatis — jadi **berfungsi langsung tanpa server tambahan**. Jika nanti ingin submission masuk otomatis ke inbox/Google Sheet, form ini bisa dihubungkan ke layanan seperti Formspree atau Resend.

## Mengganti Foto Galeri

Section **Galeri Kegiatan** saat ini berisi 4 kotak placeholder (ikon kamera). Untuk menggantinya dengan foto asli:

1. Simpan foto kegiatan Anda ke folder `assets/`, misalnya `assets/kegiatan-1.jpg`.
2. Di `index.html`, cari bagian `id="galleryGrid"`. Untuk tiap foto, ganti blok berikut:

   ```html
   <figure class="gallery-item">
     <div class="gallery-placeholder" aria-hidden="true">...</div>
     <figcaption>Foto segera ditambahkan</figcaption>
   </figure>
   ```

   menjadi:

   ```html
   <figure class="gallery-item">
     <img src="assets/kegiatan-1.jpg" alt="Sesi sebagai pembicara digital marketing di [nama acara], [tahun]" loading="lazy">
     <figcaption>[Nama acara] — [tahun]</figcaption>
   </figure>
   ```

3. Ulangi untuk foto lainnya. Anda bisa menambah lebih dari 4 foto dengan menyalin blok `<figure>` yang sama.

## Menjalankan di Lokal

Cukup buka `index.html` langsung di browser, atau jalankan server ringan:

```bash
npx serve .
```

## Deploy ke GitHub

```bash
cd artha-digital
git init
git add .
git commit -m "Website Artha Digital"
git branch -M main
git remote add origin https://github.com/USERNAME/artha-digital.git
git push -u origin main
```

## Deploy ke Vercel

**Cara termudah (tanpa CLI):**
1. Buka [vercel.com](https://vercel.com) → **Add New Project**.
2. Pilih repository `artha-digital` dari GitHub.
3. Pada bagian *Framework Preset*, pilih **Other** (situs ini statis, tidak perlu build command).
4. Klik **Deploy**.

Tidak ada langkah konfigurasi tambahan yang diperlukan — tidak ada `build command`, tidak ada `output directory` khusus, karena `index.html` berada di root proyek.

**Lewat CLI (opsional):**
```bash
npm i -g vercel
cd artha-digital
vercel --prod
```

## Catatan Desain

- Palet warna diambil langsung dari logo: biru (`#29ABE2` → `#0D4C9B`) dan oranye (`#F7941D` → `#E8622C`).
- Tipografi: **Sora** untuk judul, **Plus Jakarta Sans** untuk teks isi, **JetBrains Mono** untuk label/eyebrow.
- Elemen visual utama pada hero (garis "puncak ganda") merefleksikan bentuk logo sebagai motif pertumbuhan bisnis.
- Sudah responsif (mobile, tablet, desktop) dan mendukung navigasi keyboard.
